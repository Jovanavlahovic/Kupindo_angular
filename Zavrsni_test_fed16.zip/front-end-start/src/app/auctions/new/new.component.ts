import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kupi-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
